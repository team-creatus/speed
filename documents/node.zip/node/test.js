var myApp = angular.module('myApp', []);

myApp.factory('socket', [ '$rootScope', function($rootScope) {
	var socket = io.connect("http://localhost:3000/");
	return {
		on: function (eventName, callback) {
			socket.on(eventName, function () {
				var args = arguments;
				$rootScope.$apply(function () {
					callback.apply(socket, args);
				});
			});
		},
		emit: function (eventName, data, callback) {
			socket.emit(eventName, data, function () {
				var args = arguments;
				$rootScope.$apply(function () {
					if (callback) {
						callback.apply(socket, args);
					}
				});
			});
		}
	};
}]);

myApp.controller('myCtrl', [ '$scope', 'socket', function($scope, socket) {
	$scope.message = "";

	socket.on("messageList", function(data) {
		$scope.messageList = data;
    });

	$scope.messageSend = function() {
		socket.emit("message", $scope.message);
		$scope.message = "";
	};
}]);
