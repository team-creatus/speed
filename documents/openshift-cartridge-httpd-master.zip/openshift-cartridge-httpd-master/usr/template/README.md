You can put your static files into this folder and they'll be served by
Apache.
